1, root folder is at cm7\device\coolpad\D530
2, this folder extract to cm7\vendor\coolpad\D530
3, source code change under D530\src_change_cm7

